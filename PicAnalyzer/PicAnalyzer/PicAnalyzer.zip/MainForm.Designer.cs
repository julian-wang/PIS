﻿namespace PicAnalyzer
{
    partial class PicAnalyzer
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBoxOrig = new System.Windows.Forms.PictureBox();
            this.pictureBoxTexture = new System.Windows.Forms.PictureBox();
            this.labelOpenFile = new System.Windows.Forms.Label();
            this.textBoxOrigFile = new System.Windows.Forms.TextBox();
            this.buttonOpenFile = new System.Windows.Forms.Button();
            this.openFileDialogOrig = new System.Windows.Forms.OpenFileDialog();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.rectangleShape2 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.buttonTexture = new System.Windows.Forms.Button();
            this.tabControlStitcher = new System.Windows.Forms.TabControl();
            this.tabTexAnalyer = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pictureBoxAll = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonStitcher = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOrig)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTexture)).BeginInit();
            this.tabControlStitcher.SuspendLayout();
            this.tabTexAnalyer.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAll)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxOrig
            // 
            this.pictureBoxOrig.Location = new System.Drawing.Point(20, 88);
            this.pictureBoxOrig.Name = "pictureBoxOrig";
            this.pictureBoxOrig.Size = new System.Drawing.Size(600, 450);
            this.pictureBoxOrig.TabIndex = 0;
            this.pictureBoxOrig.TabStop = false;
            this.pictureBoxOrig.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBoxOrig_Paint);
            this.pictureBoxOrig.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBoxOrig_MouseDown);
            this.pictureBoxOrig.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBoxOrig_MouseMove);
            this.pictureBoxOrig.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBoxOrig_MouseUp);
            // 
            // pictureBoxTexture
            // 
            this.pictureBoxTexture.Location = new System.Drawing.Point(665, 315);
            this.pictureBoxTexture.Name = "pictureBoxTexture";
            this.pictureBoxTexture.Size = new System.Drawing.Size(251, 223);
            this.pictureBoxTexture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxTexture.TabIndex = 1;
            this.pictureBoxTexture.TabStop = false;
            // 
            // labelOpenFile
            // 
            this.labelOpenFile.AutoSize = true;
            this.labelOpenFile.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelOpenFile.Location = new System.Drawing.Point(39, 561);
            this.labelOpenFile.Name = "labelOpenFile";
            this.labelOpenFile.Size = new System.Drawing.Size(129, 20);
            this.labelOpenFile.TabIndex = 2;
            this.labelOpenFile.Text = "选择打开图片";
            this.labelOpenFile.Click += new System.EventHandler(this.labelOpenFile_Click);
            // 
            // textBoxOrigFile
            // 
            this.textBoxOrigFile.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBoxOrigFile.Location = new System.Drawing.Point(182, 559);
            this.textBoxOrigFile.Name = "textBoxOrigFile";
            this.textBoxOrigFile.Size = new System.Drawing.Size(250, 26);
            this.textBoxOrigFile.TabIndex = 3;
            // 
            // buttonOpenFile
            // 
            this.buttonOpenFile.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonOpenFile.Location = new System.Drawing.Point(452, 559);
            this.buttonOpenFile.Name = "buttonOpenFile";
            this.buttonOpenFile.Size = new System.Drawing.Size(73, 26);
            this.buttonOpenFile.TabIndex = 4;
            this.buttonOpenFile.Text = "选择";
            this.buttonOpenFile.UseVisualStyleBackColor = true;
            this.buttonOpenFile.Click += new System.EventHandler(this.buttonOpenFile_Click);
            // 
            // openFileDialogOrig
            // 
            this.openFileDialogOrig.FileName = "openFileDialogOrig";
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.rectangleShape2,
            this.rectangleShape1,
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(944, 682);
            this.shapeContainer1.TabIndex = 5;
            this.shapeContainer1.TabStop = false;
            // 
            // rectangleShape2
            // 
            this.rectangleShape2.Location = new System.Drawing.Point(153, 225);
            this.rectangleShape2.Name = "rectangleShape2";
            this.rectangleShape2.Size = new System.Drawing.Size(239, 124);
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.Location = new System.Drawing.Point(152, 246);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(32, 15);
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 110;
            this.lineShape1.X2 = 337;
            this.lineShape1.Y1 = 197;
            this.lineShape1.Y2 = 336;
            // 
            // buttonTexture
            // 
            this.buttonTexture.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonTexture.Location = new System.Drawing.Point(747, 559);
            this.buttonTexture.Name = "buttonTexture";
            this.buttonTexture.Size = new System.Drawing.Size(91, 26);
            this.buttonTexture.TabIndex = 6;
            this.buttonTexture.Text = "纹理分析";
            this.buttonTexture.UseVisualStyleBackColor = true;
            this.buttonTexture.Click += new System.EventHandler(this.buttonTexure_Click);
            // 
            // tabControlStitcher
            // 
            this.tabControlStitcher.Controls.Add(this.tabTexAnalyer);
            this.tabControlStitcher.Controls.Add(this.tabPage2);
            this.tabControlStitcher.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabControlStitcher.Location = new System.Drawing.Point(1, 4);
            this.tabControlStitcher.Name = "tabControlStitcher";
            this.tabControlStitcher.SelectedIndex = 0;
            this.tabControlStitcher.Size = new System.Drawing.Size(943, 678);
            this.tabControlStitcher.TabIndex = 7;
            // 
            // tabTexAnalyer
            // 
            this.tabTexAnalyer.Controls.Add(this.pictureBoxOrig);
            this.tabTexAnalyer.Controls.Add(this.buttonTexture);
            this.tabTexAnalyer.Controls.Add(this.textBoxOrigFile);
            this.tabTexAnalyer.Controls.Add(this.pictureBoxTexture);
            this.tabTexAnalyer.Controls.Add(this.buttonOpenFile);
            this.tabTexAnalyer.Controls.Add(this.labelOpenFile);
            this.tabTexAnalyer.Location = new System.Drawing.Point(4, 26);
            this.tabTexAnalyer.Name = "tabTexAnalyer";
            this.tabTexAnalyer.Padding = new System.Windows.Forms.Padding(3);
            this.tabTexAnalyer.Size = new System.Drawing.Size(935, 648);
            this.tabTexAnalyer.TabIndex = 0;
            this.tabTexAnalyer.Text = "纹理分析";
            this.tabTexAnalyer.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.pictureBoxAll);
            this.tabPage2.Controls.Add(this.pictureBox6);
            this.tabPage2.Controls.Add(this.pictureBox5);
            this.tabPage2.Controls.Add(this.pictureBox4);
            this.tabPage2.Controls.Add(this.pictureBox3);
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Controls.Add(this.pictureBox1);
            this.tabPage2.Controls.Add(this.buttonStitcher);
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(935, 648);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "图片拼接";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // pictureBoxAll
            // 
            this.pictureBoxAll.Location = new System.Drawing.Point(66, 208);
            this.pictureBoxAll.Name = "pictureBoxAll";
            this.pictureBoxAll.Size = new System.Drawing.Size(772, 314);
            this.pictureBoxAll.TabIndex = 10;
            this.pictureBoxAll.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(725, 63);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(114, 84);
            this.pictureBox6.TabIndex = 9;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(596, 63);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(114, 84);
            this.pictureBox5.TabIndex = 8;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(460, 63);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(114, 84);
            this.pictureBox4.TabIndex = 7;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(329, 63);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(114, 84);
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(199, 63);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(114, 84);
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(66, 63);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(114, 84);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // buttonStitcher
            // 
            this.buttonStitcher.Location = new System.Drawing.Point(410, 540);
            this.buttonStitcher.Name = "buttonStitcher";
            this.buttonStitcher.Size = new System.Drawing.Size(88, 32);
            this.buttonStitcher.TabIndex = 3;
            this.buttonStitcher.Text = "拼接";
            this.buttonStitcher.UseVisualStyleBackColor = true;
            this.buttonStitcher.Click += new System.EventHandler(this.buttonStitcher_Click);
            // 
            // PicAnalyzer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(944, 682);
            this.Controls.Add(this.tabControlStitcher);
            this.Controls.Add(this.shapeContainer1);
            this.Name = "PicAnalyzer";
            this.Text = "PicAnalyzer";
            this.Load += new System.EventHandler(this.PicAnalyzer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOrig)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTexture)).EndInit();
            this.tabControlStitcher.ResumeLayout(false);
            this.tabTexAnalyer.ResumeLayout(false);
            this.tabTexAnalyer.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAll)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxOrig;
        private System.Windows.Forms.PictureBox pictureBoxTexture;
        private System.Windows.Forms.Label labelOpenFile;
        private System.Windows.Forms.TextBox textBoxOrigFile;
        private System.Windows.Forms.Button buttonOpenFile;
        private System.Windows.Forms.OpenFileDialog openFileDialogOrig;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape2;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.Button buttonTexture;
        private System.Windows.Forms.TabControl tabControlStitcher;
        private System.Windows.Forms.TabPage tabTexAnalyer;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button buttonStitcher;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBoxAll;
    }
}

