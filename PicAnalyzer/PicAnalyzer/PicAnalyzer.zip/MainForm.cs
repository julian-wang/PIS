﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using Emgu.CV;
using Emgu.CV.Stitching;
using Emgu.CV.Structure;

namespace PicAnalyzer
{
    public partial class PicAnalyzer : Form
    {
        private ImageCut textureImgCut;
        Bitmap bitImg;  //定义位图对像
        private int x1;     //鼠标按下时横坐标
        private int y1;     //鼠标按下时纵坐标
        private int width;  //所打开的图像的宽
        private int heigth; //所打开的图像的高
        private bool HeadImageBool = false;    

        private Point p1;   //定义鼠标按下时的坐标点
        private Point p2;   //定义移动鼠标时的坐标点
        private Point p3;   //定义松开鼠标时的坐标点

        private string textureImg = "D:\\pictest\\texture\\t1.jpg";
        private string grayText = "D:\\pictest\\in\\g1.txt";

        public PicAnalyzer()
        {
            InitializeComponent();
        }

        private void PicAnalyzer_Load(object sender, EventArgs e)
        {

        }

        private void labelOpenFile_Click(object sender, EventArgs e)
        {

        }

        private void buttonOpenFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "D:\\pictest\\orig";
            openFileDialog.Filter = "图片文件|*.bmp;*.jpg;*.jpeg;*.gif;*.png";
            openFileDialog.RestoreDirectory = true;
            openFileDialog.FilterIndex = 1;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                //PicSelector ps = new PicSelector();
                //ps.bitOrig = new Bitmap(openFileDialog.FileName.ToString());
                //ps.Width = ps.bitOrig.Width;
                //ps.Height = ps.bitOrig.Height;
                //ps.Show();
                //textBoxOrigFile.Text = openFileDialog.FileName.ToString();
                //pictureBoxOrig.Image = Image.FromFile(openFileDialog.FileName,true);

                Image tmp = new Bitmap(openFileDialog.FileName.ToString());
                int h, w;
                if (tmp.Width * pictureBoxOrig.Height < tmp.Height * pictureBoxOrig.Width)
                {
                    h = this.pictureBoxOrig.Height;
                    w = (int)(tmp.Width * 1.0 / tmp.Height * this.pictureBoxOrig.Height);  
                }
                else
                {
                    w = this.pictureBoxOrig.Width;
                    h = (int)(tmp.Height * 1.0 / tmp.Width * this.pictureBoxOrig.Width);   
                }
                bitImg = new Bitmap(tmp, w, h);  //使用打开的图片路径创建位图对像
                ImageCut IC = new ImageCut(0,0,this.pictureBoxOrig.Width, this.pictureBoxOrig.Height);      //实例化ImageCut类，四个参数据分别表示为：x、y、width、heigth，（40、112）表示pictureBox1的Lcation的坐标，（120、144）表示pictureBox1控件的宽度和高度
                pictureBoxOrig.Image = IC.KiCut((Bitmap)(this.GetSelectImage(this.pictureBoxOrig.Width, this.pictureBoxOrig.Height)));     //（120、144）表示pictureBox1控件的宽度和高度
                //pictureBoxOrig.Image.Save("D:\\pictest\\orig.jpg", ImageFormat.Jpeg);     
            }
        }

        private void buttonTexure_Click(object sender, EventArgs e)
        {
            Image<Gray, byte> textImg = new Image<Gray, byte>(this.textureImg);
            System.IO.StreamWriter grayWriter = new System.IO.StreamWriter(this.grayText);
            for (int i = 0; i < textImg.Height; i++)
            {
                for (int j = 0; j < textImg.Width; j++)
                {
                    var tmp = textImg.Data[i,j,0];
                    grayWriter.Write(tmp+"\t");
                }
                grayWriter.WriteLine();
            }
            grayWriter.Close();
        }

        private Bitmap Crop(Bitmap bitmap)
        {
            Rectangle rec = new Rectangle(100, 100, 250, 250);
            return bitmap.Clone(rec,
                System.Drawing.Imaging.PixelFormat.Format32bppArgb);
        }

        private void pictureBoxOrig_MouseDown(object sender, MouseEventArgs e)
        {
            this.Cursor = Cursors.Cross;
            this.p1 = new Point(e.X, e.Y);
            x1 = e.X;
            y1 = e.Y;
            if (this.pictureBoxOrig.Image != null)
            {
                HeadImageBool = true;
            }
            else
            {
                HeadImageBool = false;
            }
        }

        private void pictureBoxOrig_MouseMove(object sender, MouseEventArgs e)
        {
            if (this.Cursor == Cursors.Cross)
            {
                this.p2 = new Point(e.X, e.Y);
                if ((p2.X - p1.X) > 0 && (p2.Y - p1.Y) > 0)     //当鼠标从左上角向开始移动时P3坐标
                {
                    this.p3 = new Point(p1.X, p1.Y);
                }
                if ((p2.X - p1.X) < 0 && (p2.Y - p1.Y) > 0)     //当鼠标从右上角向左下方向开始移动时P3坐标
                {
                    this.p3 = new Point(p2.X, p1.Y);
                }
                if ((p2.X - p1.X) > 0 && (p2.Y - p1.Y) < 0)     //当鼠标从左下角向上开始移动时P3坐标
                {
                    this.p3 = new Point(p1.X, p2.Y);
                }
                if ((p2.X - p1.X) < 0 && (p2.Y - p1.Y) < 0)     //当鼠标从右下角向左方向上开始移动时P3坐标
                {
                    this.p3 = new Point(p2.X, p2.Y);
                }
                this.pictureBoxOrig.Invalidate();  //使控件的整个图面无效，并导致重绘控件
            }
        }


        private void pictureBoxOrig_MouseUp(object sender, MouseEventArgs e)
        {
            if (HeadImageBool)
            {
                width = this.pictureBoxOrig.Image.Width;
                heigth = this.pictureBoxOrig.Image.Height;
                if ((e.X - x1) > 0 && (e.Y - y1) > 0)   //当鼠标从左上角向右下方向开始移动时发生
                {
                    textureImgCut = new ImageCut(x1, y1, Math.Abs(e.X - x1), Math.Abs(e.Y - y1));    //实例化ImageCut1类
                }
                if ((e.X - x1) < 0 && (e.Y - y1) > 0)   //当鼠标从右上角向左下方向开始移动时发生
                {
                    textureImgCut = new ImageCut(e.X, y1, Math.Abs(e.X - x1), Math.Abs(e.Y - y1));   //实例化ImageCut1类
                }
                if ((e.X - x1) > 0 && (e.Y - y1) < 0)   //当鼠标从左下角向右上方向开始移动时发生
                {
                    textureImgCut = new ImageCut(x1, e.Y, Math.Abs(e.X - x1), Math.Abs(e.Y - y1));   //实例化ImageCut1类
                }
                if ((e.X - x1) < 0 && (e.Y - y1) < 0)   //当鼠标从右下角向左上方向开始移动时发生
                {
                    textureImgCut = new ImageCut(e.X, e.Y, Math.Abs(e.X - x1), Math.Abs(e.Y - y1));      //实例化ImageCut1类
                }
                this.pictureBoxTexture.Width = (textureImgCut.KiCut((Bitmap)(this.pictureBoxOrig.Image))).Width;
                this.pictureBoxTexture.Height = (textureImgCut.KiCut((Bitmap)(this.pictureBoxOrig.Image))).Height;
                this.pictureBoxTexture.Image = textureImgCut.KiCut((Bitmap)(this.pictureBoxOrig.Image));
                this.pictureBoxTexture.Image.Save(this.textureImg, System.Drawing.Imaging.ImageFormat.Jpeg);    
                this.Cursor = Cursors.Default;
            }
            else
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void pictureBoxOrig_Paint(object sender, PaintEventArgs e)
        {
            if (HeadImageBool)
            {
                Pen p = new Pen(Color.Black, 2);//画笔
                p.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                //Bitmap bitmap = new Bitmap(strHeadImagePath);
                Bitmap bitmap = bitImg;
                Rectangle rect = new Rectangle(p3, new Size(System.Math.Abs(p2.X - p1.X), System.Math.Abs(p2.Y - p1.Y)));
                e.Graphics.DrawRectangle(p, rect);
            }
           
        }


        public Image GetSelectImage(int Width, int Height)
        {
            //Image initImage = this.pictureBox1.Image;
            Image initImage = bitImg;
            //原图宽高均小于模版，不作处理，直接保存 
            if (initImage.Width <= Width && initImage.Height <= Height)
            {
                //initImage.Save(fileSaveUrl, System.Drawing.Imaging.ImageFormat.Jpeg);
                return initImage;
            }
            else
            {
                //原始图片的宽、高 
                int initWidth = initImage.Width;
                int initHeight = initImage.Height;

                //非正方型先裁剪为正方型 
                if (initWidth != initHeight)
                {
                    //截图对象 
                    System.Drawing.Image pickedImage = null;
                    System.Drawing.Graphics pickedG = null;

                    //宽大于高的横图 
                    if (initWidth > initHeight)
                    {
                        //对象实例化 
                        pickedImage = new System.Drawing.Bitmap(initHeight, initHeight);
                        pickedG = System.Drawing.Graphics.FromImage(pickedImage);
                        //设置质量 
                        pickedG.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                        pickedG.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                        //定位 
                        Rectangle fromR = new Rectangle((initWidth - initHeight) / 2, 0, initHeight, initHeight);
                        Rectangle toR = new Rectangle(0, 0, initHeight, initHeight);
                        //画图 
                        pickedG.DrawImage(initImage, toR, fromR, System.Drawing.GraphicsUnit.Pixel);
                        //重置宽 
                        initWidth = initHeight;
                    }
                    //高大于宽的竖图 
                    else
                    {
                        //对象实例化
                        pickedImage = new System.Drawing.Bitmap(initWidth, initWidth);
                        pickedG = System.Drawing.Graphics.FromImage(pickedImage);
                        //设置质量 
                        pickedG.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                        pickedG.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                        //定位 
                        Rectangle fromR = new Rectangle(0, (initHeight - initWidth) / 2, initWidth, initWidth);
                        Rectangle toR = new Rectangle(0, 0, initWidth, initWidth);
                        //画图 
                        pickedG.DrawImage(initImage, toR, fromR, System.Drawing.GraphicsUnit.Pixel);
                        //重置高 
                        initHeight = initWidth;
                    }

                    initImage = (System.Drawing.Image)pickedImage.Clone();
                    //释放截图资源 
                    pickedG.Dispose();
                    pickedImage.Dispose();
                }

                return initImage;
            }
        }

        private void buttonStitcher_Click(object sender, EventArgs e)
        {
            Image<Bgr, Byte>[] sources;
            OpenFileDialog open = new OpenFileDialog();
            open.CheckFileExists = true;
            open.Multiselect = true;
            open.Filter = "打开图片|*.jpg";
            open.ShowDialog();
            sources = new Image<Bgr, byte>[open.FileNames.Length];

            for (int i = 0; i < open.FileNames.Length; i++)
            {
                sources[i] = new Image<Bgr, byte>(open.FileNames[i]);
            }

            pictureBox1.Image = new Bitmap(sources[0].Bitmap,100,75);
            pictureBox2.Image = new Bitmap(sources[1].Bitmap, 100, 75);
            pictureBox3.Image = new Bitmap(sources[2].Bitmap, 100, 75);

            Stitcher stitcher = new Stitcher(false);
            Image<Bgr, byte> result = stitcher.Stitch(sources);
            pictureBoxAll.Image = new Bitmap(result.Bitmap, 800, 350);
        }


      


    }
}
